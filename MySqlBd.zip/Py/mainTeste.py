import sqlite3
from datetime import datetime
import matplotlib.pyplot as plt 

class DalPrecipitacao:
    def __init__(self,watershed,date,precipitation):
        self.watershed = str(watershed)
        self.date = str(date)
        self.precipitation = float(precipitation)

    def get_insertion_script(self):
        return f"INSERT INTO Precipitacao (Watershed,Date ,Precipitation) VALUES('{self.watershed}','{self.date}' ,'{self.precipitation}');"

class DalAnalises:
    def __init__(self,date,ph,calcium,magnesium,sodium,potassium,ammonium,nitrate,sulfate):
        self.date = str(date)
        self.ph = float(ph)
        self.calcium = float(calcium)
        self.magnesium = float(magnesium)
        self.sodium = float(sodium)
        self.potassium = float(potassium)
        self.ammonium = float(ammonium)
        self.nitrate = float(nitrate)
        self.sulfate = float(sulfate)

    def get_insertion_script(self):
        return f"INSERT INTO Analises (Date,pH ,Calcium,Magnesium,Sodium,Potassium,Ammonium,Nitrate,Sulfate) VALUES('{self.date}','{self.ph}','{self.calcium}','{self.magnesium}','{self.sodium}','{self.potassium}','{self.ammonium}','{self.nitrate}','{self.sulfate}')"


def execute_sql_command(conn, comando):

    conn.execute(comando)
    conn.commit()

def main(nomeBD):

    conn = sqlite3.connect(nomeBD)   

    grafico(conn,"1990", "nit","sul")

    while True:
        comando = input("comando: ")
        #Funcao Fim
        if(comando.upper() == "FIM"):
            return
        else:
            run_menu(comando, nomeBD)

    conn.close()

def criaTabelas(conn):

    create_table = '''CREATE TABLE "Precipitacao" (
                    "Watershed"	TEXT,
                    "Date"	TEXT,
                    "Precipitation"	NUMERIC
                );'''

    execute_sql_command(conn,create_table)

    create_table = '''CREATE TABLE "Analises" (
                    "Date"	TEXT,
                    "pH"	NUMERIC,
                    "Calcium"	NUMERIC,
                    "Magnesium"	NUMERIC,
                    "Sodium"	NUMERIC,
                    "Potassium"	NUMERIC,
                    "Ammonium"	NUMERIC,
                    "Nitrate"	NUMERIC,
                    "Sulfate"	NUMERIC
                );'''

    execute_sql_command(conn,create_table)

def carregaPrecipitacao(con, nomeDeFicheiro):
    valores = ler_ficheiro_precipitacao(nomeDeFicheiro)

    for elemento in valores:
        execute_sql_command(con,elemento.get_insertion_script().strip())

def carregaAnalises(con,nomeDeFicheiro):
    
    valores = ler_ficheiro_analise(nomeDeFicheiro)

    for elemento in valores:
        execute_sql_command(con,elemento.get_insertion_script().strip())
    
def relatorio(conn, ano, precRef, phRef):
    query = f"select Precipitacao.Date, Precipitacao.Watershed ,Precipitacao.Precipitation ,Analises.pH from Analises inner join Precipitacao on date(Precipitacao.Date) = date(Analises.Date) \
                where  strftime('%Y',Analises.Date) = '{ano}' and Precipitacao.Precipitation > {precRef} and Analises.pH < {phRef}"


    cursor = conn.execute(query)   

    for row in cursor:
        print(f'{row[0]} {row[1]} {row[2]} {row[3]}')

def map_to_table_cloumn(cod):
    values = {
        "ph":"pH",
        "cal":"Calcium",
        "mag":"Magnesium",
        "sod":"Sodium",
        "pot":"Potassium",
        "amo":"Ammonium",
        "nit":"Nitrate",        
        "sul":"Sulfate"}

    return values[cod]

def grafico(con, ano, analise1, analise2 ):

    query = f"select Analises.{map_to_table_cloumn(analise1)}, Analises.{analise2} \
                from Analises\
                where  strftime('%Y',Analises.Date) = '{ano}' "


    cursor = con.execute(query)   

    for row in cursor:
        print(f'{row[0]} {row[1]}')

    plt.title(f'Análises ao longo do ano {ano}')    
    plt.plot()
    plt.show()
    
    
def run_menu(i, nomeBD):

    conn = sqlite3.connect(nomeBD)

    if(i=="criatab"):
        criatab(nomeBD),
    elif(i=="carregap"):
        carregap(nomeBD),
    elif(i=="carregaa"):
        carregaa(nomeBD),
    elif(i=="relatorio"):
        relatorio(nomeBD),
    elif(i=="grafico"):
        grafico(nomeBD),

def ler_ficheiro_precipitacao(file_name):
    lista = []
    file = open(file_name,'r')

    for idx,line in enumerate(file):
        if(idx == 0):
            continue

        line = line.strip()
        

        columns = line.split(',')

        lista.append( DalPrecipitacao(columns[0],columns[1],columns[2]))

    return lista

def ler_ficheiro_analise(file_name):
    lista = []
    file = open(file_name,'r')

    for idx,line in enumerate(file):
        if(idx == 0):
            continue

        line.strip()

        columns = line.split(',')

        lista.append(DalAnalises(columns[0],columns[1],columns[2],columns[3],columns[4],columns[5],columns[6],columns[7],columns[8]))

    return lista

main("mydb.db")