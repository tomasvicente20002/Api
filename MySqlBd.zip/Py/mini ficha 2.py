# -*- coding: utf-8 -*-
"""
Created on Sat Nov 28 21:27:12 2020

@author: camil
"""

#ex1
def localMax(nome_ficheiro,ano):
    """"Calcule o local onde se obteve a média mais alta"""
    X = []
    valores = []
    maior_temperatura = 0
    indiceMaior = 0 
    numeroLinha = 0
    ano=str(ano)
    file = open(nome_ficheiro,'r') 
    for line in file:
        line = line.replace("\n","")
        if(numeroLinha < 2):
            numeroLinha+=1
            continue
        elif(numeroLinha == 2): 
            X = line.split(',')
        else:
            valores = line.split(',')        
            if(valores[0]==ano):
                for idx in range(1,len(valores)):
                    valor = float(valores[idx])
                    if(valor > maior_temperatura):
                        maior_temperatura = valor
                        indiceMaior = idx
        numeroLinha+=1 
    file.close()
    return (X[indiceMaior])

#ex2
import matplotlib.pyplot as plt 

def grafTemps (nome_ficheiro,cidade_ler ):
    """desenhe um gráfico correspondente à evolução das médias das temperaturas
    máximas ao longo de todos os anos presentes no ficheiro"""
    file = open(nome_ficheiro,'r')
    anos = []
    valores = []
    numeroLinha = 0
    indice_cidade = 0
    
    for line in file:
        line = line.replace("\n","")
        if(numeroLinha < 2):
            numeroLinha+=1
            continue 
        elif(numeroLinha == 2):
           for cidade in line.split(','):
               if(cidade == cidade_ler):
                   break
               indice_cidade +=1
        else:
            valoresLinha = line.split(',')
            anos.append(int(valoresLinha[0]))
            valores.append(float(valoresLinha[indice_cidade]))
       
        numeroLinha+=1
    plt.title('x')    
    plt.plot(anos,valores)
    plt.show()